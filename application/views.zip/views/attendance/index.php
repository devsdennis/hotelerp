<?php

echo "<h1>Forbidden</h1>";
echo "<p>You don't have permission to access this resource.</p>";

?>